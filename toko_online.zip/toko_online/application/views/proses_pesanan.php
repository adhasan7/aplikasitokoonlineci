<div class="con-fluid">
	<div class="alert alert-success">
		<p class="text-center align-middle">Selamat Pesanan Anda Berhasil Di Proses</p>
	</div>
</div>

